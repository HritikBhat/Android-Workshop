package com.example.myapplication1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView sign,answer;
    Button add,sub,div,mul,eql;
    EditText number1, number2;



    public void checkInput(){
        if (number1.getText().length()>0 && number2.getText().length()>0 && !sign.getText().equals("?")){
            int num1 = Integer.valueOf(number1.getText().toString());
            int num2 = Integer.valueOf(number2.getText().toString());
            switch (sign.getText().toString()){
                case "+":
                    answer.setText(String.valueOf((num1+num2)));
                    break;
                case "-":
                    answer.setText(String.valueOf((num1-num2)));
                    break;
                case "x":
                    answer.setText(String.valueOf((num1*num2)));
                    break;
                case "/":
                    answer.setText(String.valueOf((num1/num2)));
                    break;
            }
        }
        else{
            Toast.makeText(this,"Inputs are not valid to proceed!",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1 = findViewById(R.id.num1);
        number2 = findViewById(R.id.num2);

        answer = findViewById(R.id.ans);
        sign = findViewById(R.id.sign_txt);
        add = findViewById(R.id.add_btn);
        sub = findViewById(R.id.sub_btn);
        mul = findViewById(R.id.mul_btn);
        div = findViewById(R.id.div_btn);

        eql = findViewById(R.id.eql_btn);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sign.setText("+");
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sign.setText("-");
            }
        });
        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sign.setText("x");
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sign.setText("/");
            }
        });
        eql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number1 != null || number2 != null){
                    checkInput();
                }

            }
        });
    }
}