package com.company.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    Button submit;
    EditText email,phone;
    RadioGroup genderGroup;
    RadioButton selectedRadioBtn;
    CheckBox checkBox;

    String gender_val,email_val,phone_val;

    void getValues(){
        email_val=email.getText().toString();
        phone_val = phone.getText().toString();

        Intent intent = new Intent(MainActivity.this,RegSuccessActivity.class);
        intent.putExtra("email_v",email_val);
        intent.putExtra("phone_v",phone_val);
        intent.putExtra("gender",gender_val);
        startActivity(intent);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        submit = findViewById(R.id.sub_btn);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);

        genderGroup = findViewById(R.id.genderradgrp);

        checkBox = findViewById(R.id.check_term_box);

        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                selectedRadioBtn=findViewById(checkedId);
                gender_val=selectedRadioBtn.getText().toString();
                System.out.println(gender_val);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBox.isChecked()){
                    System.out.println("Submit clicked");
                    getValues();
                }
                else{
                    System.out.println("Not accepted the T&C");
                }

            }
        });
    }
}