package com.company.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class RegSuccessActivity extends AppCompatActivity {
    String email,phone,gender;
    TextView em,ph,gn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_success);

        em=findViewById(R.id.email_txt);
        ph=findViewById(R.id.phone_txt);
        gn=findViewById(R.id.gender_txt);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        email= extras.getString("email_v");
        phone = extras.getString("phone_v");
        gender = extras.getString("gender");

        em.setText(email);
        ph.setText(phone);
        gn.setText(gender);

    }
}