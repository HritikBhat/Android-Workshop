package com.company.myapp5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    NameAdapter adapter;
    ArrayList<NameOb> name;
    Context context = this;
    Button add;
    EditText nameEd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // data to populate the RecyclerView with
        name = new ArrayList<>();

        add = findViewById(R.id.add_name_btn);
        nameEd = findViewById(R.id.name_entr);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addName();
            }
        });

        // set up the RecyclerView
        RecyclerView recyclerView = findViewById(R.id.nmlist);
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        adapter = new NameAdapter(context, name);
        adapter.setClickListener(this::onItemClick);
        recyclerView.setAdapter(adapter);
        
    }

    public void addName(){
        NameOb nmob= new NameOb((adapter.getItemCount()+1),nameEd.getText().toString());
        name.add(nmob);
        adapter.notifyDataSetChanged();
    }

    public void onItemClick(View view, int position) {
        NameOb nob= adapter.getItem(position);
        Toast.makeText(this, "You clicked " + nob.getName() + " with ID " + nob.getId(), Toast.LENGTH_SHORT).show();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_activity_actions, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.logout:
                System.out.println("Logout");
                Toast.makeText(this, "Logout",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    //rest of app
}